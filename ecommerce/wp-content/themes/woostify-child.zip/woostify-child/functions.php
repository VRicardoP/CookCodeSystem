<?php
//Function to apply styles from style.css
function custom_styles() {
    wp_enqueue_style( 'custom-admin-styles', get_stylesheet_directory_uri() . '/style.css' );
}

//Call custom styles
add_action( 'admin_enqueue_scripts', 'custom_styles' );



function cookcode_custom_script($nombre_script) {
    wp_register_script($nombre_script, get_stylesheet_directory_uri() . '/js/' . $nombre_script . '.js', array('jquery'), filemtime(get_stylesheet_directory() . '/js/' . $nombre_script . '.js'), true);

    wp_enqueue_script($nombre_script);
}

// Enqueue script 'adminmenu.js' on admin menu 
add_action('admin_enqueue_scripts', function() {
    cookcode_custom_script('adminmenu');
});




//add cart button shop page
add_action('woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart', 20);

add_filter( 'woocommerce_product_add_to_cart_text', 'cambiar_texto_boton_agotado', 10, 2 );

function custom_add_quantity_fields() {
    global $product;
    if (!$product) return;
    woocommerce_quantity_input(array(), $product, false);
}

add_action('woocommerce_after_shop_loop_item', 'custom_add_quantity_fields', 9);

add_action('woocommerce_after_shop_loop_item', 'custom_add_quantity_fields', 9);

function cambiar_texto_boton_agotado( $text, $product ) {
    if ( !$product->is_in_stock() ) {
        return __( 'Leer más', 'tu-dominio' );
    }
    return $text;
}

add_action('woocommerce_widget_shopping_cart_buttons', 'custom_view_cart_button');

function custom_view_cart_button() {
    echo '<a href="' . esc_url(wc_get_cart_url()) . '" class="button wc-forward">' . __('View Cart', 'woocommerce') . '</a>';
}

// Enqueue script 'carrito.js'on webpage
add_action('wp_enqueue_scripts', function() {
    cookcode_custom_script('carrito');
});

// Enqueue script 'manejadorEstilos.js' on webpage 
add_action('wp_enqueue_scripts', function() {
    cookcode_custom_script('manejadorEstilos');
});


//Add item on the cart
function add_to_cart_ajax_handler() {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    $result = WC()->cart->add_to_cart($product_id, $quantity);

    if ($result) {
        echo 'Producto añadido al carrito con éxito';
    } else {
        echo 'Error al añadir el producto al carrito';
    }
    wp_die();
}

add_action('wp_ajax_add_to_cart', 'add_to_cart_ajax_handler');
add_action('wp_ajax_nopriv_add_to_cart', 'add_to_cart_ajax_handler');

//update item of the cart
function update_cart_item_ajax_handler() {

    if (isset($_POST['cart_item_key']) && !empty($_POST['cart_item_key']) && isset($_POST['quantity']) && !empty($_POST['quantity'])) {
        $cart_item_key = sanitize_text_field($_POST['cart_item_key']);
        $quantity = intval($_POST['quantity']);

        WC()->cart->set_quantity($cart_item_key, $quantity, true);

        wp_send_json_success(array('message' => 'Cantidad actualizada con éxito'));
    } else {
        wp_send_json_error(array('message' => 'Datos insuficientes'));
    }

    wp_die(); 
}

add_action('wp_ajax_update_cart_item', 'update_cart_item_ajax_handler');
add_action('wp_ajax_nopriv_update_cart_item', 'update_cart_item_ajax_handler');

//remove item of the cart
function remove_from_cart_ajax_handler() {
    // Verificar el nonce (por hacer: hay que activarlo)
    // if (!wp_verify_nonce($_POST['nonce'], 'remove-cart-nonce')) {
    //    wp_send_json_error(array('message' => 'Nonce verification failed'));
    //    wp_die();
    //}

    if (isset($_POST['cart_item_key']) && !empty($_POST['cart_item_key'])) {
        $cart_item_key = sanitize_text_field($_POST['cart_item_key']);

        WC()->cart->remove_cart_item($cart_item_key);

        wp_send_json_success(array('message' => 'Producto eliminado del carrito con éxito'));
    } else {
        wp_send_json_error(array('message' => 'Datos insuficientes para eliminar el producto'));
    }

    wp_die();
}


add_action('wp_ajax_remove_from_cart', 'remove_from_cart_ajax_handler');
add_action('wp_ajax_nopriv_remove_from_cart', 'remove_from_cart_ajax_handler');

//order by a-z

add_filter('woocommerce_catalog_orderby', 'custom_woocommerce_catalog_orderby');

function custom_woocommerce_catalog_orderby($sortby) {
   
    $sortby['menu_order'] = 'Ordenar por nombre: a-z'; 

    return $sortby;
}

//remove rating order
add_filter('woocommerce_catalog_orderby', 'custom_remove_orderby_options');

function custom_remove_orderby_options($orderby) {
    unset($orderby['rating']); 
    return $orderby;
}