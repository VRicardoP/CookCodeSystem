
function cargarCSS($name) {
    const url = window.location.href; 
    if (url.endsWith('/'+$name+'/')) {
        const head = document.getElementsByTagName('head')[0];
        const link = document.createElement('link');

        //console.log("Aplicando " + $name + ".css")

        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = '/ecommerce/wp-content/themes/woostify-child/css/'+ $name + '.css'; 

        head.appendChild(link);
    }
}

function incluyeCSS($name){
    const url = window.location.href; 
    if (url.includes('/'+$name+'/')) {
        const head = document.getElementsByTagName('head')[0];
        const link = document.createElement('link');

        //console.log("Aplicando " + $name + ".css")

        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = '/ecommerce/wp-content/themes/woostify-child/css/'+ $name + '.css'; 

        head.appendChild(link);
    }
}

cargarCSS('carrito');

cargarCSS('finalizar-compra')

incluyeCSS('producto')